import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

// Nimmt den Magic-Link-Code entgegen, tauscht ihn gegen eine Session
// und leitet dann weiter (Onboarding, falls noch kein Household existiert).
export async function GET(request: Request) {
  const { searchParams, origin } = new URL(request.url);
  const code = searchParams.get("code");

  if (code) {
    const supabase = createClient();
    const { error } = await supabase.auth.exchangeCodeForSession(code);
    if (!error) {
      return NextResponse.redirect(`${origin}/`);
    }
  }

  return NextResponse.redirect(`${origin}/login?error=auth_callback_failed`);
}
